
var butei = [];

var roby = {
  nome: "Roberto",
  cognome: "Bertini",
  anni: 39,
  mezzi: ["classe A", "beverly"],
}

var kuz = {
  nome: "Yevjgieni",
  cognome: "Kuzmenko",
  anni: 37,
  mezzi: ["bici", "piè"],
}

butei.push(kuz, roby)


// maniera alternativa ma equivalente

var butei = [
  {
    nome: "Yevjgieni",
    cognome: "Kuzmenko",
    anni: 37,
    mezzi: ["bici", "piè"],
  },
  {
    nome: "Roberto",
    cognome: "Bertini",
    anni: 39,
    mezzi: ["classe A", "beverly"],
  }
];

