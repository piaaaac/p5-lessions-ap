
// Gli array sono dei contenitori.
// Possono avere più dimensioni.
// Una dimensione = come se fosse una mensola

// Azioni possibili
// creare mensola vuota
a = [];

// creare mensola con dei libri
a = [2, 5, 6, 3, 7]
a = ["kuz", "giani", "roby", "massi"]

// aggiungere un libro in fondo
a.push(1)

// leggere la dimensione dell'array
a.length

// aggingere un libro all'inizio
a.unshift(9)

// scegliere un libro in posizione x (ad esempio 3)
a[3]

// prendere (e togliere) l'ultimo libro
a.pop()

// prendere (e togliere) un libro in posizione x (ad esempio 2)
a.splice(2, 1)

